cordova.define("faylib-plugin-network.Network", function(require, exports, module) {
var exec = require('cordova/exec');
var base = require('faylib-plugin-base.Plugin');

var network = 'Network';

/**
* 调试模式
* @param openOrNot 是否打开
*/
exports.debugMode = function (openOrNot) {
	exec(null, null, network, base.debugMode, [openOrNot]);
};

/**
* 设置超时时隔
* @param millisecond 时隔（毫秒）
*/
exports.timeoutInterval = function (millisecond) {
	exec(null, null, network, base.timeoutInterval, [millisecond]);
};

/**
* 设置重试次数
* @param count 次数
*/
exports.retryTimes = function (count) {
	exec(null, null, network, base.retryTimes, [count]);
};

/**
* 设置请求头
* @param headers 请求头参数
*/
exports.setHeaders = function (headers) {
	exec(null, null, network, base.setHeaders, [headers]);
};

/**
* 发送 GET 请求
* @param url 请求接口
* @param params 请求参数
* @param successCallback 请求成功回调
* @param errorCallback 请求失败回调
*/
exports.GET = function (url, params, successCallback, errorCallback) {
	exec(successCallback, errorCallback, network, base.requestGet, [url, params]);
};

/**
* 发送 POST 请求
* @param url 请求接口
* @param params 请求参数
* @param successCallback 请求成功回调
* @param errorCallback 请求失败回调
*/
exports.POST = function (url, params, successCallback, errorCallback) {
	exec(successCallback, errorCallback, network, base.requestPost, [url, params]);
};

/**
* 发送 DELETE 请求
* @param url 请求接口
* @param params 请求参数
* @param successCallback 请求成功回调
* @param errorCallback 请求失败回调
*/
exports.DELETE = function (url, params, successCallback, errorCallback) {
	exec(successCallback, errorCallback, network, base.requestDelete, [url, params]);
};

/**
* 发送 download 请求
* @param url 请求接口
* @param filePath 文件保存路径
* @param successCallback 请求成功回调
* @param errorCallback 请求失败回调
*/
exports.download = function (url, filePath, successCallback, errorCallback) {
	exec(successCallback, errorCallback, network, base.requestDownload, [url, filePath]);
};

/**
* 重置请求
*/
exports.reset = function () {
	exec(null, null, network, base.resetRequest, []);
};

/**
* 打开网络监听
* @param callback 回调
*/
exports.startMonitoring = function (callback) {
	exec(callback, null, network, base.startMonitoring, []);
};

/**
* 关闭网络监听
* @param callback 回调
*/
exports.stopMonitoring = function (callback) {
	exec(callback, null, network, base.stopMonitoring, []);
};

/**
* 当前网络状态
* @param callback 回调
*/
exports.reachability = function (callback) {
	exec(callback, null, network, base.networkReachability, []);
};

});
