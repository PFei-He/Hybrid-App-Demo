cordova.define("faylib-plugin-base.Plugin", function(require, exports, module) {
var encrypt = false;

// Base
exports.debugMode = encrypt ? 'aldk3sf3jiowe1jio' : 'debug_mode';

// Network
exports.timeoutInterval = encrypt ? 'aqwer232f388ojlk' : 'timeout_interval';
exports.retryTimes = encrypt ? 'aihelkj89a0yhuahfqhef' : 'retry_times';
exports.setHeaders = encrypt ? 'ha8907fh97hfuq89ye4h8' : 'set_headers';
exports.requestGet = encrypt ? 'j982fh9ygaiffhy93gao' : 'request_get';
exports.requestPost = encrypt ? 'ja9hf487a84gf78alcb' : 'request_post';
exports.requestDelete = encrypt ? 'haf89qof7s80fgdi3d' : 'request_delete';
exports.requestDownload = encrypt ? 'dahe89qeqlf8c7ae' : 'request_download';
exports.resetRequest = encrypt ? 'a98323po2ha90alcbvgaonmx' : 'reset_request';
exports.startMonitoring = encrypt ? 'afj982bfklaj3b298fh' : 'start_monitoring';
exports.stopMonitoring = encrypt ? 'dijoefnaakhf923bfbcn' : 'stop_monitoring';
exports.networkReachability = encrypt ? 'jvb32bskf309v8akdhj' : 'network_reachability';

});
