import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-search',
  templateUrl: 'find.html'
})
export class FindPage {

  constructor(public navCtrl: NavController) {

  }

}
