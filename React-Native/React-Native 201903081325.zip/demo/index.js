/** @format */

import {AppRegistry} from 'react-native';
import App from './web/App';
import {name as appName} from './web/app.json';

AppRegistry.registerComponent(appName, () => App);
