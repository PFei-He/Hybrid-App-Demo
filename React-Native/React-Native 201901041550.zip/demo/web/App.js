/**
 * Copyright (c) 2018 faylib.top
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

import React, { Component } from 'react';
import { Image, View, Text, StyleSheet } from 'react-native'
import { createAppContainer, createBottomTabNavigator, createStackNavigator, TabBarBottom } from 'react-navigation';
import Home from './src/Home';
import Find from './src/Find';
import Me from './src/Me';

type Props = {};
export default class App extends Component<Props> {
    render() {
        return (
            <TabBar/>
        )
    }
}

const TabBar = createAppContainer(createBottomTabNavigator(
    {
        HOME: createStackNavigator({
            Home: Home,
        }),
        FIND: createStackNavigator({
            Find: Find,
        }),
        ME: createStackNavigator({
            Me: Me,
        }),
    },
    {
        defaultNavigationOptions: ({ navigation }) => ({
            tabBarIcon: ({ focused, tintColor }) => {
                const { routeName } = navigation.state;
                if (routeName === 'HOME') {
                    return <Image source={focused?require('./assets/img/tab_home_selected.png'):require('./assets/img/tab_home_normal.png')} style={styles.image} />;
                } else if (routeName === 'FIND') {
                    return <Image source={focused?require('./assets/img/tab_find_selected.png'):require('./assets/img/tab_find_normal.png')} style={styles.image} />;
                } else if (routeName === 'ME') {
                    return <Image source={focused?require('./assets/img/tab_me_selected.png'):require('./assets/img/tab_me_normal.png')} style={styles.image} />;
                }
            },
        }),
        tabBarComponent: TabBarBottom,
        tabBarPosition: 'bottom',
        tabBarOptions: {
            activeTintColor: 'tomato',
            inactiveTintColor: 'gray',
        },
        animationEnabled: false,
        swipeEnabled: false,
    }
));

const styles = StyleSheet.create({
    image: {
        width: 30,
        height: 30,
    }
});
