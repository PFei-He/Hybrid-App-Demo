//
//  Copyright (c) 2019 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

#import "FLPlugin.h"

NS_ASSUME_NONNULL_BEGIN

#if 0==1
#define timeout_interval aqwer232f388ojlk
#define retry_times aihelkj89a0yhuahfqhef
#define set_headers ha8907fh97hfuq89ye4h8
#define request_get j982fh9ygaiffhy93gao
#define request_post ja9hf487a84gf78alcb
#define request_delete haf89qof7s80fgdi3d
#define request_download dahe89qeqlf8c7ae
#define reset_request a98323po2ha90alcbvgaonmx
#define start_monitoring afj982bfklaj3b298fh
#define stop_monitoring dijoefnaakhf923bfbcn
#define network_reachability jvb32bskf309v8akdhj
#endif

@interface FLNetwork : FLPlugin

@end

NS_ASSUME_NONNULL_END
