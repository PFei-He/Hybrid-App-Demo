/**
 * Copyright (c) 2019 faylib.top
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

// region Private Variable

var encrypt = false;

var method = {
  timeoutInterval: encrypt ? 'aqwer232f388ojlk' : 'timeout_interval',
  retryTimes: encrypt ? 'aihelkj89a0yhuahfqhef' : 'retry_times',
  setHeaders: encrypt ? 'ha8907fh97hfuq89ye4h8' : 'set_headers',
  requestGet: encrypt ? 'j982fh9ygaiffhy93gao' : 'request_get',
  requestPost: encrypt ? 'ja9hf487a84gf78alcb' : 'request_post',
  requestDelete: encrypt ? 'haf89qof7s80fgdi3d' : 'request_delete',
  requestDownload: encrypt ? 'dahe89qeqlf8c7ae' : 'request_download',
  resetRequest: encrypt ? 'a98323po2ha90alcbvgaonmx' : 'reset_request',
  startMonitoring: encrypt ? 'afj982bfklaj3b298fh' : 'start_monitoring',
  stopMonitoring: encrypt ? 'dijoefnaakhf923bfbcn' : 'stop_monitoring',
  networkReachability: encrypt ? 'jvb32bskf309v8akdhj' : 'network_reachability'
}

// endregion

// region Public Variable

var network = module.exports;

/**
 * 插件名
 */
network.name = 'Network';

/**
 * 定义网络状态
 * @type {{wifi: string, wwan: string, none: string, unknown: string}}
 */
network.status = {
  unknown: 'FL_NETWORK_REACHABILITY_STATUS_UNKNOWN',
  none: 'FL_NETWORK_REACHABILITY_STATUS_NONE',
  wwan: 'FL_NETWORK_REACHABILITY_STATUS_WWAN',
  wifi: 'FL_NETWORK_REACHABILITY_STATUS_WIFI'
};

// endregion

// region Cordova Plugin Methods (Web -> Native)

/**
 * 设置超时时隔
 * @param millisecond 时隔（毫秒）
 */
network.timeoutInterval = function (millisecond) {
  cordova.exec(null, null, network.name, method.timeoutInterval, [millisecond]);
};

/**
 * 设置重试次数
 * @param count 次数
 */
network.retryTimes = function (count) {
  cordova.exec(null, null, network.name, method.retryTimes, [count]);
};

/**
 * 设置请求头
 * @param headers 请求头参数
 */
network.setHeaders = function (headers) {
  cordova.exec(null, null, network.name, method.setHeaders, [headers]);
};

/**
 * 发送 GET 请求
 * @param url 请求接口
 * @param params 请求参数
 * @param successCallback 请求成功回调
 * @param errorCallback 请求失败回调
 */
network.GET = function (url, params, successCallback, errorCallback) {
  cordova.exec(successCallback, errorCallback, network.name, method.requestGet, [url, params]);
};

/**
 * 发送 POST 请求
 * @param url 请求接口
 * @param params 请求参数
 * @param successCallback 请求成功回调
 * @param errorCallback 请求失败回调
 */
network.POST = function (url, params, successCallback, errorCallback) {
  cordova.exec(successCallback, errorCallback, network.name, method.requestPost, [url, params]);
};

/**
 * 发送 DELETE 请求
 * @param url 请求接口
 * @param params 请求参数
 * @param successCallback 请求成功回调
 * @param errorCallback 请求失败回调
 */
network.DELETE = function (url, params, successCallback, errorCallback) {
  cordova.exec(successCallback, errorCallback, network.name, method.requestDelete, [url, params]);
};

/**
 * 发送 download 请求
 * @param url 请求接口
 * @param filePath 文件保存路径
 * @param successCallback 请求成功回调
 * @param errorCallback 请求失败回调
 */
network.download = function (url, filePath, successCallback, errorCallback) {
  cordova.exec(successCallback, errorCallback, network.name, method.requestDownload, [url, filePath]);
};

/**
 * 重置请求
 */
network.reset = function () {
  cordova.exec(null, null, network.name, method.resetRequest, []);
};

/**
 * 打开网络监听
 * @param callback 回调
 */
network.startMonitoring = function (callback) {
  cordova.exec(callback, null, network.name, method.startMonitoring, []);
};

/**
 * 关闭网络监听
 * @param callback 回调
 */
network.stopMonitoring = function (callback) {
  cordova.exec(callback, null, network.name, method.stopMonitoring, []);
};

/**
 * 当前网络状态
 * @param callback 回调
 */
network.reachability = function (callback) {
  cordova.exec(callback, null, network.name, method.networkReachability, []);
};

// endregion
