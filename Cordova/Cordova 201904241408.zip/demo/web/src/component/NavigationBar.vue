/**
* Copyright (c) 2018 faylib.top
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/

<template>
    <div class="navigation-bar" ref="navigationBar" v-if="showNavigationBar">
        <!-- 左边区域 -->
        <div class="navigation-bar-side">
            <span class="navigation-bar-item" v-if="showLiftItem">
                <slot name="navigation-bar-left" />
            </span>
        </div>

        <!-- 标题 -->
        <span class="navigation-bar-title">
            <slot />
        </span>

        <!-- 右边区域 -->
        <div class="navigation-bar-side">
            <span class="navigation-bar-item" v-if="showRightItem">
                <slot name="navigation-bar-right" />
            </span>
        </div>
    </div>
</template>

<script>
    export default {
        name: 'NavigationBar',
        props: { // 双向绑定属性
            showNavigationBar: {
                type: Boolean,
                default: true
            },
            showLiftItem: {
                type: Boolean,
                default: true
            },
            showRightItem: {
                type: Boolean,
                default: true
            }
        }
    }
</script>

<style scoped lang="less">
    @import "../assets/less/component";

    .navigation-bar {
        height: 44px;
        line-height: 44px;
        background-color: @navigation-bar-background-color;
        color: @navigation-bar-title-color;
        width: 100%;
        -webkit-touch-callout:none;  /* 系统默认菜单被禁用 */
        -webkit-user-select:none; /* webkit 浏览器 */
        -khtml-user-select:none; /* 早期浏览器 */
        -moz-user-select:none; /* 火狐 */
        -ms-user-select:none; /* IE10 */
        user-select:none;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-tap-highlight-color: transparent; /* For some Androids */

        .navigation-bar-side {
            height: 44px;
            width: 23%;
            float: left;

            .navigation-bar-item {
                float: left;
                height: 44px;
                width: 100%;
            }
        }

        .navigation-bar-title {
            height: 44px;
            float: left;
            width: 54%;
            text-align: center;
            font-size: 17px;
        }
    }
</style>
