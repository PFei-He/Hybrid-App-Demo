/**
* Copyright (c) 2018 faylib.top
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/

<template>
    <div class="app">
        <navigation-bar :show-lift-item="showBack" :show-right-item="false">
            <img slot="navigation-bar-left" :src="navigationBarItem.back" @click="back">
            {{title}}
        </navigation-bar>

        <div class="content">
            <router-view></router-view>
        </div>

        <tab-bar :show-tab-bar="showTabBar" v-model="tabBarIndex">
            <tab-bar-item v-for="item in tabBarItem" :key="item" :page="item.label.toLowerCase()" has-route="true">
                <img slot="tab-bar-item-icon-normal" :src="item.normal">
                <img slot="tab-bar-item-icon-selected" :src="item.selected">
                {{item.label}}
            </tab-bar-item>
        </tab-bar>
    </div>
</template>

<script>
    import NavigationBar from './component/NavigationBar'
    import TabBar from './component/TabBar'
    import TabBarItem from './component/TabBarItem'

    export default {
        name: 'App',
        components: { NavigationBar, TabBar, TabBarItem },
        props: {
            showTabBar: {
                type: Boolean,
                default: false
            }
        },
        computed: {
            showBack () {
                return this.$route.name.toUpperCase() !== 'HOME' && this.$route.name.toUpperCase() !== 'FIND' && this.$route.name.toUpperCase() !== 'ME'
            },
            title () {
                return this.$route.name.toUpperCase()
            }
        },
        methods: {
            back () {
                this.$router.go(-1)
            }
        },
        data () {
            return {
                navigationBarItem: {
                    back: require('./assets/img/navigation_bar_back.png')
                },
                tabBarItem: [
                    {
                        normal: require('./assets/img/tab_home_normal.png'),
                        selected: require('./assets/img/tab_home_selected.png'),
                        label: 'HOME',
                        link: '/home'
                    },
                    {
                        normal: require('./assets/img/tab_find_normal.png'),
                        selected: require('./assets/img/tab_find_selected.png'),
                        label: 'FIND',
                        link: '/find'
                    },
                    {
                        normal: require('./assets/img/tab_me_normal.png'),
                        selected: require('./assets/img/tab_me_selected.png'),
                        label: 'ME',
                        link: '/me'
                    }
                ],
                tabBarIndex: 'home'
            }
        }
    }
</script>

<style lang="less">
    /**
      name { 标签选择器 => <name>
        ...
      }

      .name { 类选择器 => <div class="name"></div>
        ...
      }

      #name { 控件选择器 => <div id="name"></div>
        ...
      }
     */

    body {
        margin: 0 auto;
    }

    .app {
        height: 100%;
    }

    a:any-link {
        text-decoration: none;
    }
</style>



/* 引用外部文件 (.js) 作为本文件的 script */
<!--<script src=".."></script>-->

/* 引用外部文件 (.css/.scss/...) 作为本文件的 style */
/* 这样写的css文件中的样式只能在本组件中使用，而不会影响其他组件 */
<!--<style src=".."></style>-->
/* 这样写的话import的css文件会被编译为全局样式，但是引入less等预编译文件，就会局部生效 */
<!--<style>@import "..";</style>-->
<!--<style>@import url("..");</style>-->
