/**
* Copyright (c) 2018 faylib.top
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/

<template>
    <div class="tab-bar-item" :class="{'is-selected': isSelected}" ref="tabBarItem" @click="toRoute">

        <!-- 普通状态图片 -->
        <span class="tab-bar-item-icon" v-show="!isSelected">
            <slot name="tab-bar-item-icon-normal" />
        </span>

        <!-- 选择状态图片 -->
        <span class="tab-bar-item-icon" v-show="isSelected">
            <slot name="tab-bar-item-icon-selected"></slot>
        </span>

        <!--文字 -->
        <span class="tab-bar-item-text">
            <slot />
        </span>
    </div>
</template>

<script>
    export default {
        name: 'TabBarItem',
        props: {
            page: {
                type: String,
                default: ''
            },
            hasRoute: {
                type: Boolean,
                default: false
            }
        },
        computed: {
            isSelected () {
                if (this.$parent.value === this.page) {
                    return true
                }
            }
        },
        methods: {
            toRoute () {
                this.$parent.$emit('input', this.page)
                if (this.hasRoute) {
                    this.$router.push(this.page)
                }
            }
        }
    }
</script>

<style scoped lang="less">
    @import "../assets/less/component";

    .tab-bar-item {
        flex: 1;
        text-align: center;
        line-height: 13px;
        -webkit-touch-callout:none;  /* 系统默认菜单被禁用 */
        -webkit-user-select:none; /* webkit 浏览器 */
        -khtml-user-select:none; /* 早期浏览器 */
        -moz-user-select:none; /* 火狐 */
        -ms-user-select:none; /* IE10 */
        user-select:none;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
        -webkit-tap-highlight-color: transparent; /* For some Androids */

        .tab-bar-item-icon {
            display: block;

            img {
                width: 30px;
                height: 30px;
            }
        }

        .tab-bar-item-text {
            display: block;
            font-size: 13px;
            color: @tab-bar-title-color;
        }

        &.is-selected {
            .tab-bar-item-text {
                color: @tab-bar-title-color-selected;
            }
        }
    }
</style>
