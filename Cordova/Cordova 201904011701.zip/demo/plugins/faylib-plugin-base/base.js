/**
 * Copyright (c) 2019 faylib.top
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

// region Private Variable

var encrypt = false;

// endregion

// region Public Variable

var base = module.exports;

base.method = {
    // Base
    debugMode: (encrypt ? 'aldk3sf3jiowe1jio' : 'debug_mode'),

    // Network
    timeoutInterval: encrypt ? 'aqwer232f388ojlk' : 'timeout_interval',
    retryTimes: encrypt ? 'aihelkj89a0yhuahfqhef' : 'retry_times',
    setHeaders: encrypt ? 'ha8907fh97hfuq89ye4h8' : 'set_headers',
    requestGet: encrypt ? 'j982fh9ygaiffhy93gao' : 'request_get',
    requestPost: encrypt ? 'ja9hf487a84gf78alcb' : 'request_post',
    requestDelete: encrypt ? 'haf89qof7s80fgdi3d' : 'request_delete',
    requestDownload: encrypt ? 'dahe89qeqlf8c7ae' : 'request_download',
    resetRequest: encrypt ? 'a98323po2ha90alcbvgaonmx' : 'reset_request',
    startMonitoring: encrypt ? 'afj982bfklaj3b298fh' : 'start_monitoring',
    stopMonitoring: encrypt ? 'dijoefnaakhf923bfbcn' : 'stop_monitoring',
    networkReachability: encrypt ? 'jvb32bskf309v8akdhj' : 'network_reachability',
}

// endregion

// region Cordova Plugin Methods (Web -> Native)

/**
 * 调试模式
 * @param plugin 需要设置调试模式的插件
 * @param openOrNot 是否打开
 */
base.debugMode = function (plugin, openOrNot) {
    cordova.exec(null, null, plugin, this.method.debugMode, [openOrNot]);
};

/**
 * 加密模式
 * @param openOrNot 是否打开
 */
base.encryptMode = function (openOrNot) {
    encrypt = openOrNot;
};

// endregion
