/**
 * Copyright (c) 2019 faylib.top
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

// region Private Variable

var base = require('../faylib-plugin-base/base');

// endregion

// region Public Variable

var network = module.exports;

/**
 * 插件名
 */
network.name = 'Network';

/**
 * 定义网络状态
 * @type {{wifi: string, wwan: string, none: string, unknown: string}}
 */
network.status = {
  unknown: 'FL_NETWORK_REACHABILITY_STATUS_UNKNOWN',
  none: 'FL_NETWORK_REACHABILITY_STATUS_NONE',
  wwan: 'FL_NETWORK_REACHABILITY_STATUS_WWAN',
  wifi: 'FL_NETWORK_REACHABILITY_STATUS_WIFI'
};

// endregion

// region Cordova Plugin Methods (Web -> Native)

/**
 * 设置超时时隔
 * @param millisecond 时隔（毫秒）
 */
network.timeoutInterval = function (millisecond) {
  cordova.exec(null, null, network.name, base.method.timeoutInterval, [millisecond]);
};

/**
 * 设置重试次数
 * @param count 次数
 */
network.retryTimes = function (count) {
  cordova.exec(null, null, network.name, base.method.retryTimes, [count]);
};

/**
 * 设置请求头
 * @param headers 请求头参数
 */
network.setHeaders = function (headers) {
  cordova.exec(null, null, network.name, base.method.setHeaders, [headers]);
};

/**
 * 发送 GET 请求
 * @param url 请求接口
 * @param params 请求参数
 * @param successCallback 请求成功回调
 * @param errorCallback 请求失败回调
 */
network.GET = function (url, params, successCallback, errorCallback) {
  cordova.exec(successCallback, errorCallback, network.name, base.method.requestGet, [url, params]);
};

/**
 * 发送 POST 请求
 * @param url 请求接口
 * @param params 请求参数
 * @param successCallback 请求成功回调
 * @param errorCallback 请求失败回调
 */
network.POST = function (url, params, successCallback, errorCallback) {
  cordova.exec(successCallback, errorCallback, network.name, base.method.requestPost, [url, params]);
};

/**
 * 发送 DELETE 请求
 * @param url 请求接口
 * @param params 请求参数
 * @param successCallback 请求成功回调
 * @param errorCallback 请求失败回调
 */
network.DELETE = function (url, params, successCallback, errorCallback) {
  cordova.exec(successCallback, errorCallback, network.name, base.method.requestDelete, [url, params]);
};

/**
 * 发送 download 请求
 * @param url 请求接口
 * @param filePath 文件保存路径
 * @param successCallback 请求成功回调
 * @param errorCallback 请求失败回调
 */
network.download = function (url, filePath, successCallback, errorCallback) {
  cordova.exec(successCallback, errorCallback, network.name, base.method.requestDownload, [url, filePath]);
};

/**
 * 重置请求
 */
network.reset = function () {
  cordova.exec(null, null, network.name, base.method.resetRequest, []);
};

/**
 * 打开网络监听
 * @param callback 回调
 */
network.startMonitoring = function (callback) {
  cordova.exec(callback, null, network.name, base.method.startMonitoring, []);
};

/**
 * 关闭网络监听
 * @param callback 回调
 */
network.stopMonitoring = function (callback) {
  cordova.exec(callback, null, network.name, base.method.stopMonitoring, []);
};

/**
 * 当前网络状态
 * @param callback 回调
 */
network.reachability = function (callback) {
  cordova.exec(callback, null, network.name, base.method.networkReachability, []);
};

// endregion
