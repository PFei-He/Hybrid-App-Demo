/**
 * Copyright (c) 2018 faylib.top
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

package top.faylib.plugins.network;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.MethodChannel.MethodCallHandler;
import io.flutter.plugin.common.MethodChannel.Result;
import io.flutter.plugin.common.PluginRegistry.Registrar;

/** NetworkPlugin */
public class NetworkPlugin implements MethodCallHandler {
    //region Constant

    // 定义网络状态
    private static final String FL_NETWORK_REACHABILITY_STATUS_UNKNOWN = "FL_NETWORK_REACHABILITY_STATUS_UNKNOWN";
    private static final String FL_NETWORK_REACHABILITY_STATUS_NONE = "FL_NETWORK_REACHABILITY_STATUS_NONE";
    private static final String FL_NETWORK_REACHABILITY_STATUS_WWAN = "FL_NETWORK_REACHABILITY_STATUS_WWAN";
    private static final String FL_NETWORK_REACHABILITY_STATUS_WIFI = "FL_NETWORK_REACHABILITY_STATUS_WIFI";

    //endregion


    //region Private Variable

    // 调试模式
    private boolean debugMode = true;

    // 请求队列
    private RequestQueue queue = null;

    // 超时时隔
    private int timeoutInterval = 120000;

    // 重试次数
    private int retryTimes = 1;

    // 请求头
    private Map<String, String> headers = new HashMap<>();

    // 请求结果状态码
    private int statusCode;

    // 插件注册器
    private Registrar registrar;

    //endregion


    //region Private Methods

    // 打印调试信息
    private void debugLog(String ... strings) {
        if (debugMode) {
            for (String string : strings) {
                Log.i("FayLIB", "[ FayLIB ][ NETWORK ]" + string + ".");
            }
        }
    }

    // JSONObject 格式转 Map<String, String> 格式
    private static Map<String, String> toStringMap(JSONObject jsonObject) throws JSONException {
        Map<String, String> map = new HashMap<>();
        Iterator<String> keys = jsonObject.keys();
        while(keys.hasNext()) {
            String key = keys.next();
            map.put(key, jsonObject.getString(key));
        }   return map;
    }

    // JSONObject 格式转 Map<String, Object> 格式
    private static Map<String, Object> toObjectMap(JSONObject jsonObject) throws JSONException {
        Map<String, Object> map = new HashMap<>();
        Iterator<String> keys = jsonObject.keys();
        while(keys.hasNext()) {
            String key = keys.next();
            Object value = jsonObject.get(key);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value);
            } else if (value instanceof JSONObject) {
                value = toObjectMap((JSONObject) value);
            }
            map.put(key, value);
        }   return map;
    }

    // JSONArray 格式转 List<Object> 格式
    private static List<Object> toList(JSONArray jsonArray) throws JSONException {
        List<Object> list = new ArrayList<>();
        for(int i = 0; i < jsonArray.length(); i++) {
            Object value = jsonArray.get(i);
            if (value instanceof JSONArray) {
                value = toList((JSONArray) value);
            } else if (value instanceof JSONObject) {
                value = toObjectMap((JSONObject) value);
            }
            list.add(value);
        }   return list;
    }

    // 拼接参数
    private String appendParameter(String url, Map<String, String> params) {
        Uri uri = Uri.parse(url);
        Uri.Builder builder = uri.buildUpon();
        for(Map.Entry<String, String> entry : params.entrySet()) {
            builder.appendQueryParameter(entry.getKey(), entry.getValue());
        }
        return builder.build().getQuery();
    }

    // 发送请求
    private void request(int method, String url, Map params, int retryTimes, Result result) {
        switch (method) {
            case 0:
                debugLog(retryTimes == this.retryTimes ? "[ REQUEST ] Start sending" : "[ REQUEST ] Retrying",
                        "[ URL ] " + url,
                        "[ METHOD ] GET",
                        "[ PARAMS ] " + (params == null ? "{}" : params.toString()),
                        "[ RETRY TIMES ] " + String.valueOf(retryTimes),
                        "[ TIMEOUT INTERVAL ] " + String.valueOf(timeoutInterval/1000));
                break;
            case 1:
                debugLog(retryTimes == this.retryTimes ? "[ REQUEST ] Start sending" : "[ REQUEST ] Retrying",
                        "[ URL ] " + url,
                        "[ METHOD ] POST",
                        "[ PARAMS ] " + (params == null ? "{}" : params.toString()),
                        "[ RETRY TIMES ] " + String.valueOf(retryTimes),
                        "[ TIMEOUT INTERVAL ] " + String.valueOf(timeoutInterval/1000));
                break;
            case 3:
                debugLog(retryTimes == this.retryTimes ? "[ REQUEST ] Start sending" : "[ REQUEST ] Retrying",
                        "[ URL ] " + url,
                        "[ METHOD ] DELETE",
                        "[ PARAMS ] " + (params == null ? "{}" : params.toString()),
                        "[ RETRY TIMES ] " + String.valueOf(retryTimes),
                        "[ TIMEOUT INTERVAL ] " + String.valueOf(timeoutInterval/1000));
                break;
            default:
                break;
        }

        retryTimes--;
        final int count = retryTimes;
        final int finalMethod = method;
        final String finalURL = url;
        final Map finalParams = params;
        final Result finalResult = result;

        JsonObjectRequest request = new JsonObjectRequest(method, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                parse(finalURL, statusCode, response, finalResult);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                if (count < 1) {
                    parse(finalURL, statusCode, error, finalResult);
                } else {
                    request(finalMethod, finalURL, finalParams, count, finalResult);
                }
            }
        }) {
            // 重写请求头
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                headers.putAll(super.getHeaders());
                debugLog("[ HEADERS ] " + headers.toString());
                return headers;
            }

            // 重写请求体的内容类型
            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded; charset=" + getParamsEncoding();
            }

            // 重写请求体
            @Override
            public byte[] getBody() {
                try {
                    final String string = appendParameter(finalURL, finalParams);
                    return string.getBytes(PROTOCOL_CHARSET);
                } catch (UnsupportedEncodingException uee) {
                    return null;
                }
            }

            // 重写解析服务器返回的数据
            @Override
            protected Response<JSONObject> parseNetworkResponse(NetworkResponse response) {
                statusCode = response.statusCode;
                return super.parseNetworkResponse(response);
            }
        };

        // 添加请求超时时隔
        request.setRetryPolicy(new DefaultRetryPolicy(timeoutInterval,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        // 添加请求到队列
        queue.add(request);
    }

    // 监听下载
    private void listener(final long id, final ArrayList arrayList, final Result result) {
        // 注册广播监听系统的下载完成事件
        IntentFilter intentFilter = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
        BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) == id) {
                    parse((String) arrayList.get(1), DownloadManager.STATUS_SUCCESSFUL, (String) arrayList.get(1), result);
                }
            }
        };
        registrar.activity().registerReceiver(broadcastReceiver, intentFilter);
    }

    // 数据处理
    private void parse(String url, int statusCode, Object object, Result result) {
        // 处理请求结果
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("statusCode", statusCode);
            jsonObject.put("result", object.toString());
        } catch (JSONException e) { e.printStackTrace(); }

        // 回调结果到 Web 端
        if (statusCode == 200) {
            if (object instanceof JSONObject) {
                debugLog("[ REQUEST ] Success", "[ URL ] " + url);
                result.success(jsonObject.toString());
            } else {
                debugLog("[ REQUEST ] Success but not JSON data", "[ URL ] " + url);
                result.success(jsonObject.toString());
            }
        } else {
            debugLog("[ REQUEST ] Failure", "[ URL ] " + url);
            result.success(jsonObject.toString());
        }
    }

    //endregion


    //region Flutter Plugin Methods

    public static void registerWith(Registrar registrar) {
        final MethodChannel channel = new MethodChannel(registrar.messenger(), "plugins.faylib.top/network");
        NetworkPlugin networkPlugin = new NetworkPlugin();
        networkPlugin.queue = Volley.newRequestQueue(registrar.activeContext());
        networkPlugin.registrar = registrar;
        channel.setMethodCallHandler(networkPlugin);
    }

    @Override
    public void onMethodCall(MethodCall call, Result result) {
        // 设备版本号
        if ("getPlatformVersion".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            result.success("Android " + android.os.Build.VERSION.RELEASE);
        }

        // 调试模式开关
        else if ("debugMode".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run", " Debug Mode Open");
            debugMode = (boolean) call.arguments;
        }

        // 设置超时时隔
        else if ("timeoutInterval".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            timeoutInterval = (int) call.arguments;
        }

        // 设置重试次数
        else if ("retryTimes".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            retryTimes = (int) call.arguments;
        }

        // 设置请求头
        else if ("setHeaders".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            Map map = (Map) call.arguments;
            headers.putAll(map);
        }

        // 发送 GET 请求
        else if ("requestGET".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            ArrayList arrayList = (ArrayList) call.arguments;
            request(Request.Method.GET, (String) arrayList.get(0), (Map) arrayList.get(1), retryTimes, result);
        }

        // 发送 POST 请求
        else if ("requestPOST".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            ArrayList arrayList = (ArrayList) call.arguments;
            request(Request.Method.POST, (String) arrayList.get(0), (Map) arrayList.get(1), retryTimes, result);
        }

        // 发送 DELETE 请求
        else if ("requestDELETE".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            ArrayList arrayList = (ArrayList) call.arguments;
            request(Request.Method.DELETE, (String) arrayList.get(0), (Map) arrayList.get(1), retryTimes, result);
        }

        // 发送下载请求
        else if ("requestDownload".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            ArrayList arrayList = (ArrayList) call.arguments;
            DownloadManager downloadManager = (DownloadManager)registrar.activity().getSystemService(Context.DOWNLOAD_SERVICE);
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse((String) arrayList.get(0)));
            request.setDestinationInExternalFilesDir(registrar.activity(), null, (String) arrayList.get(1));
            long downloadId = downloadManager != null ? downloadManager.enqueue(request) : 0;
            listener(downloadId, (ArrayList) call.arguments, result);
        }

        // 重置请求
        else if ("resetRequest".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            timeoutInterval = 120000;
            retryTimes = 1;
        }

        // 打开网络监听
        else if ("startMonitoring".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            IntentFilter filter = new IntentFilter();
            filter.addAction(NetworkStatus.NET_CHANGE_ACTION);
            NetworkStatus networkStatus = new NetworkStatus();
            registrar.activity().registerReceiver(networkStatus, filter);
            NetworkStatus.Status status = new NetworkStatus.Status() {
                @Override
                public void onChange(NetworkStatus.Type type) {

                }
            };
            NetworkStatus.Observer.register(status);
        }

        // 关闭网络监听
        else if ("stopMonitoring".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            NetworkStatus.Observer.unregister();
        }

        // 网络状态
        else if ("networkReachability".equals(call.method)) {
            debugLog("[ FUNCTION ] '" + call.method + "' run");
            ConnectivityManager connectivityManager = (ConnectivityManager)registrar.activity().getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            assert connectivityManager != null;
            NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
            if (networkInfo != null && networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
                result.success(FL_NETWORK_REACHABILITY_STATUS_WWAN);
            } else if (networkInfo != null && networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                result.success(FL_NETWORK_REACHABILITY_STATUS_WIFI);
            } else {
                result.success(FL_NETWORK_REACHABILITY_STATUS_NONE);
            }
        }

        else {
            result.notImplemented();
        }
    }

    //endregion
}
