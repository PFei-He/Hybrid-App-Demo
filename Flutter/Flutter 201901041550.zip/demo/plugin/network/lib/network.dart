//
//  Copyright (c) 2018 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

import 'dart:async';
import 'package:flutter/services.dart';

class Network {
    static const MethodChannel _channel = const MethodChannel('plugins.faylib.top/network');

    // 设备版本号
    static Future<String> get platformVersion async {
        final String version = await _channel.invokeMethod('getPlatformVersion');
        return version;
    }

    // 调试模式开关
    static debugMode(trueOrFalse) async {
        await _channel.invokeMethod('debugMode', trueOrFalse);
    }

    // 设置超时时隔
    static timeoutInterval(millisecond) async {
        await _channel.invokeMethod('timeoutInterval', millisecond);
    }

    // 设置重试次数
    static retryTimes(count) async {
        await _channel.invokeMethod('timeoutInterval', count);
    }

    // 设置请求头
    static Future<String> setHeaders(url, parameters) async {
        final String response = await _channel.invokeMethod('setHeaders', [url, parameters]);
        return response;
    }

    // 发送 GET 请求
    static Future<String> GET(url, parameters) async {
        final String response = await _channel.invokeMethod('requestGET', [url, parameters]);
        return response;
    }

    // 发送 POST 请求
    static Future<String> POST(url, parameters) async {
        final String response = await _channel.invokeMethod('requestGET', [url, parameters]);
        return response;
    }

    // 发送 DELETE 请求
    static Future<String> DELETE(url, parameters) async {
        final String response = await _channel.invokeMethod('requestGET', [url, parameters]);
        return response;
    }

    // 发送 download 请求
    static Future<String> Download(url, parameters) async {
        final String response = await _channel.invokeMethod('requestDownload', [url, parameters]);
        return response;
    }

    // 重置请求
    static resetRequest() async {
        await _channel.invokeMethod('resetRequest', null);
    }

    // 打开网络监听
    static Future<String> startMonitoring() async {
        final String status = await _channel.invokeMethod('startMonitoring', null);
        return status;
    }

    // 关闭网络监听
    static Future<String> stopMonitoring() async {
        final String status = await _channel.invokeMethod('stopMonitoring', null);
        return status;
    }

    // 当前网络状态
    static Future<String> reachability() async {
        final String status = await _channel.invokeMethod('reachability', null);
        return status;
    }
}
