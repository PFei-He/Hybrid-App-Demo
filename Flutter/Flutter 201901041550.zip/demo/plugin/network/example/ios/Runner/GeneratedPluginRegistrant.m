//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <network/NetworkPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [NetworkPlugin registerWithRegistrar:[registry registrarForPlugin:@"NetworkPlugin"]];
}

@end
