//
//  Copyright (c) 2018 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

#import "NetworkPlugin.h"
#import <AFNetworking.h>

// 调试打印
#define DLog(args...)\
[self debugLog:args, nil]

typedef NS_ENUM(NSUInteger, FLNetworkRequestMethod) {
    FLNetworkRequestMethodGET,
    FLNetworkRequestMethodPOST,
    FLNetworkRequestMethodDELETE,
    FLNetworkRequestMethodDownload
};

// 定义网络状态
NSString * const FL_NETWORK_REACHABILITY_STATUS_UNKNOWN = @"FL_NETWORK_REACHABILITY_STATUS_UNKNOWN";
NSString * const FL_NETWORK_REACHABILITY_STATUS_NONE = @"FL_NETWORK_REACHABILITY_STATUS_NONE";
NSString * const FL_NETWORK_REACHABILITY_STATUS_WWAN = @"FL_NETWORK_REACHABILITY_STATUS_WWAN";
NSString * const FL_NETWORK_REACHABILITY_STATUS_WIFI = @"FL_NETWORK_REACHABILITY_STATUS_WIFI";

@interface NetworkPlugin ()

/// 调试模式
@property (nonatomic, assign) BOOL debugMode;

/// 网络请求
@property (nonatomic, strong) AFHTTPSessionManager *sessionManager;

/// 网络状态
@property (nonatomic, strong) AFNetworkReachabilityManager *reachabilityManager;

/// 超时时隔
@property (nonatomic) NSInteger timeoutInterval;

/// 重试次数
@property (nonatomic) NSInteger retryTimes;

@end

@implementation NetworkPlugin

#pragma mark - Setter / Getter Methods

- (AFHTTPSessionManager *)sessionManager
{
    if (!_sessionManager) {
        _sessionManager = [AFHTTPSessionManager manager];
        _sessionManager.requestSerializer.timeoutInterval = 120;
        _sessionManager.responseSerializer.acceptableContentTypes = [_sessionManager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
    }
    return _sessionManager;
}

// 初始化监控
- (AFNetworkReachabilityManager *)reachabilityManager
{
    if (!_reachabilityManager) {
        _reachabilityManager = [AFNetworkReachabilityManager sharedManager];
    }
    return _reachabilityManager;
}

// 超时时隔
- (void)setTimeoutInterval:(NSInteger)timeoutInterval
{
    self.sessionManager.requestSerializer.timeoutInterval = timeoutInterval;
    _timeoutInterval = timeoutInterval;
}

// 重试次数
- (NSInteger)retryTimes
{
    if (_retryTimes == 0) {
        _retryTimes = 1;
    }
    return _retryTimes;
}


#pragma mark - Private Methods

// 打印调试信息
- (void)debugLog:(NSString *)strings, ...
{
    if (self.debugMode) {
        NSLog(@"[ FayLIB ][ NETWORK ]%@.", strings);
        va_list list;
        va_start(list, strings);
        while (strings != nil) {
            NSString *string = va_arg(list, NSString *);
            if (!string) break;
            NSLog(@"[ FayLIB ][ NETWORK ]%@.", string);
        }
        va_end(list);
    }
}

// 解析 JSON
- (NSString *)parseJSON:(id)json
{
    NSError *error;
    NSString *jsonString;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:json options:NSJSONWritingPrettyPrinted error:&error];
    if (jsonData) jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonString;
}

// 发送请求
- (void)sendWithMethod:(FLNetworkRequestMethod)method retryTimes:(NSInteger)count response:(FlutterMethodCall *)call result:(FlutterResult)result
{
    switch (method) {
        case FLNetworkRequestMethodGET:
        {
            DLog(count == self.retryTimes ? @"[ REQUEST ] Start sending" : @"[ REQUEST ] Retrying",
                 [NSString stringWithFormat:@"[ URL ] %@", call.arguments[0]],
                 @"[ METHOD ] GET",
                 [NSString stringWithFormat:@"[ PARAMS ] %@", call.arguments[1]],
                 [NSString stringWithFormat:@"[ RETRY TIMES ] %@", @(count)],
                 [NSString stringWithFormat:@"[ TIMEOUT INTERVAL ] %@", @(self.sessionManager.requestSerializer.timeoutInterval)],
                 [NSString stringWithFormat:@"[ HEADERS ] %@", self.sessionManager.requestSerializer.HTTPRequestHeaders]);
            
            count--;
            
            [self.sessionManager GET:call.arguments[0] parameters:call.arguments[1] success:^(NSURLSessionDataTask * _Nonnull task, id _Nonnull responseObject) {
                [self parseWithMethod:FLNetworkRequestMethodGET response:(NSHTTPURLResponse *)task.response responseObject:responseObject call:call result:result];
            } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
                if (count < 1) [self parseWithMethod:FLNetworkRequestMethodGET response:(NSHTTPURLResponse *)task.response responseObject:[NSString stringWithFormat:@"%@", error] call:call result:result];
                else [self sendWithMethod:FLNetworkRequestMethodGET retryTimes:count response:call result:result];
            }];
        }
            break;
        case FLNetworkRequestMethodPOST:
        {
            DLog(count == self.retryTimes ? @"[ REQUEST ] Start sending" : @"[ REQUEST ] Retrying",
                 [NSString stringWithFormat:@"[ URL ] %@", call.arguments[0]],
                 @"[ METHOD ] POST",
                 [NSString stringWithFormat:@"[ PARAMS ] %@", call.arguments[1]],
                 [NSString stringWithFormat:@"[ RETRY TIMES ] %@", @(count)],
                 [NSString stringWithFormat:@"[ TIMEOUT INTERVAL ] %@", @(self.sessionManager.requestSerializer.timeoutInterval)],
                 [NSString stringWithFormat:@"[ HEADERS ] %@", self.sessionManager.requestSerializer.HTTPRequestHeaders]);
            
            count--;
            
            [self.sessionManager POST:call.arguments[0] parameters:call.arguments[1] success:^(NSURLSessionDataTask * _Nonnull task, id _Nonnull responseObject) {
                [self parseWithMethod:FLNetworkRequestMethodPOST response:(NSHTTPURLResponse *)task.response responseObject:responseObject call:call result:result];
            } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
                if (count < 1) [self parseWithMethod:FLNetworkRequestMethodPOST response:(NSHTTPURLResponse *)task.response responseObject:[NSString stringWithFormat:@"%@", error] call:call result:result];
                else [self sendWithMethod:FLNetworkRequestMethodPOST retryTimes:count response:call result:result];
            }];
        }
            break;
        case FLNetworkRequestMethodDELETE:
        {
            DLog(count == self.retryTimes ? @"[ REQUEST ] Start sending" : @"[ REQUEST ] Retrying",
                 [NSString stringWithFormat:@"[ URL ] %@", call.arguments[0]],
                 @"[ METHOD ] DELETE",
                 [NSString stringWithFormat:@"[ PARAMS ] %@", call.arguments[1]],
                 [NSString stringWithFormat:@"[ RETRY TIMES ] %@", @(count)],
                 [NSString stringWithFormat:@"[ TIMEOUT INTERVAL ] %@", @(self.sessionManager.requestSerializer.timeoutInterval)],
                 [NSString stringWithFormat:@"[ HEADERS ] %@", self.sessionManager.requestSerializer.HTTPRequestHeaders]);
            
            count--;
            
            [self.sessionManager DELETE:call.arguments[0] parameters:call.arguments[1] success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
                [self parseWithMethod:FLNetworkRequestMethodDELETE response:(NSHTTPURLResponse *)task.response responseObject:responseObject call:call result:result];
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                if (count < 1) [self parseWithMethod:FLNetworkRequestMethodDELETE response:(NSHTTPURLResponse *)task.response responseObject:[NSString stringWithFormat:@"%@", error] call:call result:result];
                else [self sendWithMethod:FLNetworkRequestMethodDELETE retryTimes:count response:call result:result];
            }];
        }
            break;
        case FLNetworkRequestMethodDownload:
        {
            DLog(count == self.retryTimes ? @"[ REQUEST ] Start sending" : @"[ REQUEST ] Retrying",
                 [NSString stringWithFormat:@"[ URL ] %@", call.arguments[0]],
                 @"[ METHOD ] Download",
                 [NSString stringWithFormat:@"[ FILE PATH ] %@", call.arguments[1]],
                 [NSString stringWithFormat:@"[ RETRY TIMES ] %@", @(count)],
                 [NSString stringWithFormat:@"[ TIMEOUT INTERVAL ] %@", @(self.sessionManager.requestSerializer.timeoutInterval)],
                 [NSString stringWithFormat:@"[ HEADERS ] %@", self.sessionManager.requestSerializer.HTTPRequestHeaders]);
            
            count--;
            
            NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:call.arguments[0]]];
            NSURLSessionDownloadTask *downloadTask = [self.sessionManager downloadTaskWithRequest:request progress:nil destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
                // 保存路径
                return [NSURL fileURLWithPath:call.arguments[1]];
            } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
                if (!error) {
                    [self parseWithMethod:FLNetworkRequestMethodDownload response:(NSHTTPURLResponse *)response responseObject:filePath call:call result:result];
                } else {
                    if (count < 1) [self parseWithMethod:FLNetworkRequestMethodDownload response:(NSHTTPURLResponse *)response responseObject:error call:call result:result];
                    else [self sendWithMethod:FLNetworkRequestMethodDownload retryTimes:count response:call result:result];
                }
            }];
            [downloadTask resume];
        }
            break;
        default:
            break;
    }
}

// 数据处理
- (void)parseWithMethod:(FLNetworkRequestMethod)method response:(NSHTTPURLResponse *)response responseObject:(id)object call:(FlutterMethodCall *)call result:(FlutterResult)result
{
    // 回调结果到 Web 端
    if (response.statusCode == 200) {
        switch (method) {
            case FLNetworkRequestMethodGET:
            case FLNetworkRequestMethodPOST:
            case FLNetworkRequestMethodDELETE:
            {
                if ([object isKindOfClass:[NSDictionary class]]) {
                    DLog(@"[ REQUEST ] Success", [NSString stringWithFormat:@"[ URL ] %@", call.arguments[0]]);
                    result([NSString stringWithFormat:@"%@", @{@"statusCode": @(response.statusCode), @"result": object}]);
                } else {
                    DLog(@"[ REQUEST ] Success but not JSON data", [NSString stringWithFormat:@"[ URL ] %@", call.arguments[0]]);
                    result([NSString stringWithFormat:@"%@", @{@"statusCode": @(response.statusCode), @"result": [NSString stringWithFormat:@"%@", object]}]);
                }
            }
                break;
            case FLNetworkRequestMethodDownload:
            {
                if ([object isKindOfClass:[NSURL class]]) {
                    DLog(@"[ REQUEST ] Success", [NSString stringWithFormat:@"[ URL ] %@", call.arguments[0]]);
                    result([NSString stringWithFormat:@"%@", @{@"statusCode": @(response.statusCode), @"result": [NSString stringWithFormat:@"%@", object]}]);
                } else {
                    DLog(@"[ REQUEST ] Success but error file", [NSString stringWithFormat:@"[ URL ] %@", call.arguments[0]]);
                    result([NSString stringWithFormat:@"%@", @{@"statusCode": @(response.statusCode), @"result": [NSString stringWithFormat:@"%@", object]}]);
                }
            }
                break;
            default:
                break;
        }
    } else {
        DLog(@"[ REQUEST ] Failure", [NSString stringWithFormat:@"[ URL ] %@", call.arguments[0]]);
        result([NSString stringWithFormat:@"%@", @{@"statusCode": @(response.statusCode), @"result": [NSString stringWithFormat:@"%@", object]}]);
    }
}


#pragma mark - Flutter Plugin Methods

+ (void)registerWithRegistrar:(NSObject<FlutterPluginRegistrar> *)registrar
{
    FlutterMethodChannel* channel = [FlutterMethodChannel methodChannelWithName:@"plugins.faylib.top/network" binaryMessenger:[registrar messenger]];
    NetworkPlugin* instance = [[NetworkPlugin alloc] init];
    [registrar addMethodCallDelegate:instance channel:channel];
}

- (void)handleMethodCall:(FlutterMethodCall *)call result:(FlutterResult)result
{
    // 设备版本号
    if ([@"getPlatformVersion" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        result([@"iOS " stringByAppendingString:[[UIDevice currentDevice] systemVersion]]);
    }
    
    // 调试模式开关
    else if ([@"debugMode" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method], @" Debug Mode Open");
        self.debugMode = call.arguments;
    }
    
    // 设置超时时隔
    else if ([@"timeoutInterval" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        self.timeoutInterval = [call.arguments integerValue] / 1000;
    }
    
    // 设置重试次数
    else if ([@"retryTimes" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        self.retryTimes = [call.arguments integerValue];
    }
    
    // 设置请求头
    else if ([@"setHeaders" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        [call.arguments enumerateKeysAndObjectsUsingBlock:^(id  _Nonnull key, id  _Nonnull obj, BOOL * _Nonnull stop) {
            [self.sessionManager.requestSerializer setValue:obj forHTTPHeaderField:key];
        }];
    }
    
    // 发送 GET 请求
    else if ([@"requestGET" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        [self sendWithMethod:FLNetworkRequestMethodGET retryTimes:self.retryTimes response:call result:result];
    }
    
    // 发送 POST 请求
    else if ([@"requestPOST" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        [self sendWithMethod:FLNetworkRequestMethodPOST retryTimes:self.retryTimes response:call result:result];
    }
    
    // 发送 DELETE 请求
    else if ([@"requestDELETE" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        [self sendWithMethod:FLNetworkRequestMethodDELETE retryTimes:self.retryTimes response:call result:result];
    }
    
    // 发送下载请求
    else if ([@"requestDownload" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        [self sendWithMethod:FLNetworkRequestMethodDownload retryTimes:self.retryTimes response:call result:result];
    }
    
    // 重置请求
    else if ([@"resetRequest" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        self.timeoutInterval = 120;
        self.retryTimes = 1;
    }
    
    // 打开网络监听
    else if ([@"startMonitoring" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        [self.reachabilityManager startMonitoring];
//        __weak __typeof__(self) weakSelf = self;
        [self.reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
//            __typeof__(weakSelf) self = weakSelf;
            switch (status) {
                case AFNetworkReachabilityStatusUnknown:
                    break;
                case AFNetworkReachabilityStatusNotReachable:
                    break;
                case AFNetworkReachabilityStatusReachableViaWWAN:
                    break;
                case AFNetworkReachabilityStatusReachableViaWiFi:
                    break;
                default:
                    break;
            }
        }];
    }
    
    // 关闭网络监听
    else if ([@"stopMonitoring" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        [self.reachabilityManager stopMonitoring];
    }
    
    // 网络状态
    else if ([@"networkReachability" isEqualToString:call.method]) {
        DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", call.method]);
        if (self.reachabilityManager.networkReachabilityStatus == AFNetworkReachabilityStatusReachableViaWWAN) {
        } else if (self.reachabilityManager.networkReachabilityStatus == AFNetworkReachabilityStatusReachableViaWiFi) {
        } else {
        }
    }
    
    else {
        result(FlutterMethodNotImplemented);
    }
}

@end
