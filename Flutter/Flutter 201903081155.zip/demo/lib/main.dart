//
//  Copyright (c) 2018 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'src/home.dart';
import 'src/find.dart';
import 'src/me.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
    @override
    State<StatefulWidget> createState() => new Main();
}

class Main extends State<MyApp> {
    /* Private Variables */
    int _tabIndex = 0;
    var _body;
    var images;
    var titles = ['HOME', 'FIND', 'ME'];
    final normal = new TextStyle(color: Colors.grey);
    final selected = new TextStyle(color: const Color(0xFFFF6347));


    /* Life Cycle */
    @override
    Widget build(BuildContext context) {
        initData();
        return new MaterialApp(
            theme: new ThemeData(
                primaryColor: Colors.white
            ),
            home: new Scaffold(
                appBar: new AppBar(
                    title: new Text(titles[_tabIndex], style: new TextStyle(color: Color(0xFFFF6347))),
                ),
                body: _body,
                bottomNavigationBar: new CupertinoTabBar(
                    items: <BottomNavigationBarItem>[
                        new BottomNavigationBarItem(
                            icon: icon(0),
                            title: title(0)),
                        new BottomNavigationBarItem(
                            icon: icon(1),
                            title: title(1)),
                        new BottomNavigationBarItem(
                            icon: icon(2),
                            title: title(2)),
                    ],
                    currentIndex: _tabIndex,
                    onTap: (index) {
                        setState(() {
                            _tabIndex = index;
                        });
                    },
                ),
            ),
        );
    }


    /* Private Methods */
    // Tab Bar Image
    SvgPicture image(path) {
        return new SvgPicture.asset(path, width: 30, height: 30);
    }
    SvgPicture icon(int index) {
        if (index == _tabIndex) {
            return images[index][1];
        }
        return images[index][0];
    }

    // Tab Bar Text
    Text title(int index) {
        return new Text(titles[index], style: style(index));
    }
    TextStyle style(int index) {
        if (index == _tabIndex) {
            return selected;
        }
        return normal;
    }

    // Data
    void initData () {
        if (images == null) {
            images = [
                [
                    image('lib/assets/img/tab_home_normal.svg'),
                    image('lib/assets/img/tab_home_selected.svg')
                ],
                [
                    image('lib/assets/img/tab_find_normal.svg'),
                    image('lib/assets/img/tab_find_selected.svg')
                ],
                [
                    image('lib/assets/img/tab_me_normal.svg'),
                    image('lib/assets/img/tab_me_selected.svg')
                ]
            ];
        }

        _body = new IndexedStack(
            children: <Widget>[
                new Home(),
                new Find(),
                new Me()
            ],
            index: _tabIndex,
        );
    }
}
