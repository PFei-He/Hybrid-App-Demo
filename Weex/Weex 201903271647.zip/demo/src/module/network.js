/**
 * Copyright (c) 2019 faylib.top
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

// region Macro Definition

// 网络接口
var Network = 'Network'

// endregion

export default {
  // region Public Variable

  // 定义网络状态
  status: {
    unknown: 'FL_NETWORK_REACHABILITY_STATUS_UNKNOWN',
    none: 'FL_NETWORK_REACHABILITY_STATUS_NONE',
    wwan: 'FL_NETWORK_REACHABILITY_STATUS_WWAN',
    wifi: 'FL_NETWORK_REACHABILITY_STATUS_WIFI'
  },

  // endregion

  // region Weex Module Methods (Web -> Native)

  /**
   * 调试模式
   * @param openOrNot 是否打开
   */
  debugMode (openOrNot) {
    weex.requireModule(Network).debug_mode(openOrNot)
  },

  /**
   * 设置超时时隔
   * @param millisecond 时隔（毫秒）
   */
  timeoutInterval (millisecond) {
    weex.requireModule(Network).timeout_interval(millisecond)
  },

  /**
   * 设置重试次数
   * @param count 次数
   */
  retryTimes (count) {
    weex.requireModule(Network).retry_times(count)
  },

  /**
   * 设置请求头
   * @param headers 请求头参数
   */
  setHeaders (headers) {
    weex.requireModule(Network).set_headers(headers)
  },

  /**
   * 发送 GET 请求
   * @param url 请求接口
   * @param params 请求参数
   * @param callback 请求结束回调
   */
  GET (url, params, callback) {
    weex.requireModule(Network).request_get([url, params], callback)
  },

  /**
   * 发送 POST 请求
   * @param url 请求接口
   * @param params 请求参数
   * @param callback 请求结束回调
   */
  POST (url, params, callback) {
    weex.requireModule(Network).request_post([url, params], callback)
  },

  /**
   * 发送 DELETE 请求
   * @param url 请求接口
   * @param params 请求参数
   * @param callback 请求结束回调
   */
  DELETE (url, params, callback) {
    weex.requireModule(Network).request_delete([url, params], callback)
  },

  /**
   * 发送 download 请求
   * @param url 请求接口
   * @param filePath 文件保存路径
   * @param callback 请求结束回调
   */
  download (url, filePath, callback) {
    weex.requireModule(Network).request_download([url, filePath], callback)
  },

  /**
   * 重置请求
   */
  reset () {
    weex.requireModule(Network).reset_request()
  },

  /**
   * 打开网络监听
   * @param callback 回调
   */
  startMonitoring (callback) {
    weex.requireModule(Network).start_monitoring(callback)
  },

  /**
   * 关闭网络监听
   */
  stopMonitoring () {
    weex.requireModule(Network).stop_monitoring()
  },

  /**
   * 当前网络状态
   * @param callback 回调
   */
  reachability (callback) {
    weex.requireModule(Network).network_reachability(callback)
  }

  // endregion
}
