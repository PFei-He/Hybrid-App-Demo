import App from '../src/index.vue'
App.el = '#root'
new Vue(App)
