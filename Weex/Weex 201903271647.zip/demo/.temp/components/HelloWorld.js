import App from '../../src/components/HelloWorld.vue'
App.el = '#root'
new Vue(App)
