package top.faylib.module;

import com.taobao.weex.annotation.JSMethod;
import com.taobao.weex.bridge.JSCallback;
import com.taobao.weex.common.WXModule;

import org.json.JSONArray;

public class Network extends WXModule {
    @JSMethod (uiThread = false)
    public void debug_mode(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void timeout_interval(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void retry_times(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void set_headers(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void request_get(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void request_post(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void request_delete(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void request_download(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void reset_request(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void start_monitoring(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void stop_monitoring(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }

    @JSMethod (uiThread = false)
    public void network_reachability(JSONArray array, JSCallback callback) {
        callback.invoke("");
    }
}
