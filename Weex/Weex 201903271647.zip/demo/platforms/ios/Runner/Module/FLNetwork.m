//
//  Copyright (c) 2019 faylib.top
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.
//

#import "FLNetwork.h"
#import <AFNetworking/AFNetworking.h>

typedef NS_ENUM(NSUInteger, FLNetworkRequestMethod) {
    FLNetworkRequestMethodGET,
    FLNetworkRequestMethodPOST,
    FLNetworkRequestMethodDELETE,
    FLNetworkRequestMethodDownload
};

// 定义网络状态
NSString * const FL_NETWORK_REACHABILITY_STATUS_UNKNOWN = @"FL_NETWORK_REACHABILITY_STATUS_UNKNOWN";
NSString * const FL_NETWORK_REACHABILITY_STATUS_NONE = @"FL_NETWORK_REACHABILITY_STATUS_NONE";
NSString * const FL_NETWORK_REACHABILITY_STATUS_WWAN = @"FL_NETWORK_REACHABILITY_STATUS_WWAN";
NSString * const FL_NETWORK_REACHABILITY_STATUS_WIFI = @"FL_NETWORK_REACHABILITY_STATUS_WIFI";

@interface FLNetwork ()

// 网络请求
@property (nonatomic, strong) AFHTTPSessionManager *sessionManager;

// 网络状态
@property (nonatomic, strong) AFNetworkReachabilityManager *reachabilityManager;

// 超时时隔
@property (nonatomic) NSInteger timeoutInterval;

// 重试次数
@property (nonatomic) NSInteger retryTimes;

@end

@implementation FLNetwork

WX_EXPORT_METHOD(@selector(timeout_interval:))
WX_EXPORT_METHOD(@selector(retry_times:))
WX_EXPORT_METHOD(@selector(set_headers:))
WX_EXPORT_METHOD(@selector(request_get:callback:))
WX_EXPORT_METHOD(@selector(request_post:callback:))
WX_EXPORT_METHOD(@selector(request_delete:callback:))
WX_EXPORT_METHOD(@selector(request_download:callback:))
WX_EXPORT_METHOD(@selector(reset_request))
WX_EXPORT_METHOD(@selector(start_monitoring:))
WX_EXPORT_METHOD(@selector(stop_monitoring))
WX_EXPORT_METHOD(@selector(network_reachability:))

#pragma mark - Setter / Getter Methods

// 初始化请求
- (AFHTTPSessionManager *)sessionManager
{
    if (!_sessionManager) {
        _sessionManager = [AFHTTPSessionManager manager];
        _sessionManager.requestSerializer.timeoutInterval = 120;
        _sessionManager.responseSerializer.acceptableContentTypes = [_sessionManager.responseSerializer.acceptableContentTypes setByAddingObject:@"text/html"];
        _sessionManager.responseSerializer.acceptableContentTypes = [_sessionManager.responseSerializer.acceptableContentTypes setByAddingObject:@"image/*"];
    }
    return _sessionManager;
}

// 初始化监控
- (AFNetworkReachabilityManager *)reachabilityManager
{
    if (!_reachabilityManager) {
        _reachabilityManager = [AFNetworkReachabilityManager sharedManager];
    }
    return _reachabilityManager;
}

// 超时时隔
- (void)setTimeoutInterval:(NSInteger)timeoutInterval
{
    self.sessionManager.requestSerializer.timeoutInterval = timeoutInterval;
    _timeoutInterval = timeoutInterval;
}

// 重试次数
- (NSInteger)retryTimes
{
    if (_retryTimes == 0) {
        _retryTimes = 1;
    }
    return _retryTimes;
}


#pragma mark - Private Methods

// 解析 JSON
- (NSString *)parseJSON:(id)json
{
    NSError *error;
    NSString *jsonString;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:json options:NSJSONWritingPrettyPrinted error:&error];
    if (jsonData) jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonString;
}

// 发送请求
- (void)sendWithMethod:(FLNetworkRequestMethod)method retryTimes:(NSInteger)count messages:(NSArray *)messages response:(WXModuleCallback)callback
{
    switch (method) {
        case FLNetworkRequestMethodGET:
        {
            DLog(count == self.retryTimes ? @"[ REQUEST ] Start sending" : @"[ REQUEST ] Retrying",
                 [NSString stringWithFormat:@"[ URL ] %@", messages[0]],
                 @"[ METHOD ] GET",
                 [NSString stringWithFormat:@"[ PARAMS ] %@", messages[1]],
                 [NSString stringWithFormat:@"[ RETRY TIMES ] %@", @(count)],
                 [NSString stringWithFormat:@"[ TIMEOUT INTERVAL ] %@", @(self.sessionManager.requestSerializer.timeoutInterval)],
                 [NSString stringWithFormat:@"[ HEADERS ] %@", self.sessionManager.requestSerializer.HTTPRequestHeaders]);
            
            count--;
            
            [self.sessionManager GET:messages[0] parameters:messages[1] success:^(NSURLSessionDataTask * _Nonnull task, id _Nonnull responseObject) {
                [self parseWithMethod:FLNetworkRequestMethodGET response:(NSHTTPURLResponse *)task.response result:responseObject messages:messages callback:callback];
            } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
                if (count < 1) [self parseWithMethod:FLNetworkRequestMethodGET response:(NSHTTPURLResponse *)task.response result:[NSString stringWithFormat:@"%@", error] messages:messages callback:callback];
                else [self sendWithMethod:FLNetworkRequestMethodGET retryTimes:count messages:messages response:callback];
            }];
        }
            break;
        case FLNetworkRequestMethodPOST:
        {
            DLog(count == self.retryTimes ? @"[ REQUEST ] Start sending" : @"[ REQUEST ] Retrying",
                 [NSString stringWithFormat:@"[ URL ] %@", messages[0]],
                 @"[ METHOD ] POST",
                 [NSString stringWithFormat:@"[ PARAMS ] %@", messages[1]],
                 [NSString stringWithFormat:@"[ RETRY TIMES ] %@", @(count)],
                 [NSString stringWithFormat:@"[ TIMEOUT INTERVAL ] %@", @(self.sessionManager.requestSerializer.timeoutInterval)],
                 [NSString stringWithFormat:@"[ HEADERS ] %@", self.sessionManager.requestSerializer.HTTPRequestHeaders]);
            
            count--;
            
            [self.sessionManager POST:messages[0] parameters:messages[1] success:^(NSURLSessionDataTask * _Nonnull task, id _Nonnull responseObject) {
                [self parseWithMethod:FLNetworkRequestMethodPOST response:(NSHTTPURLResponse *)task.response result:responseObject messages:messages callback:callback];
            } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
                if (count < 1) [self parseWithMethod:FLNetworkRequestMethodPOST response:(NSHTTPURLResponse *)task.response result:[NSString stringWithFormat:@"%@", error] messages:messages callback:callback];
                else [self sendWithMethod:FLNetworkRequestMethodPOST retryTimes:count messages:messages response:callback];
            }];
        }
            break;
        case FLNetworkRequestMethodDELETE:
        {
            DLog(count == self.retryTimes ? @"[ REQUEST ] Start sending" : @"[ REQUEST ] Retrying",
                 [NSString stringWithFormat:@"[ URL ] %@", messages[0]],
                 @"[ METHOD ] DELETE",
                 [NSString stringWithFormat:@"[ PARAMS ] %@", messages[1]],
                 [NSString stringWithFormat:@"[ RETRY TIMES ] %@", @(count)],
                 [NSString stringWithFormat:@"[ TIMEOUT INTERVAL ] %@", @(self.sessionManager.requestSerializer.timeoutInterval)],
                 [NSString stringWithFormat:@"[ HEADERS ] %@", self.sessionManager.requestSerializer.HTTPRequestHeaders]);
            
            count--;
            
            [self.sessionManager DELETE:messages[0] parameters:messages[1] success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
                [self parseWithMethod:FLNetworkRequestMethodDELETE response:(NSHTTPURLResponse *)task.response result:responseObject messages:messages callback:callback];
            } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                if (count < 1) [self parseWithMethod:FLNetworkRequestMethodDELETE response:(NSHTTPURLResponse *)task.response result:[NSString stringWithFormat:@"%@", error] messages:messages callback:callback];
                else [self sendWithMethod:FLNetworkRequestMethodDELETE retryTimes:count messages:messages response:callback];
            }];
        }
            break;
        case FLNetworkRequestMethodDownload:
        {
            DLog(count == self.retryTimes ? @"[ REQUEST ] Start sending" : @"[ REQUEST ] Retrying",
                 [NSString stringWithFormat:@"[ URL ] %@", messages[0]],
                 @"[ METHOD ] Download",
                 [NSString stringWithFormat:@"[ FILE PATH ] %@", messages[1]],
                 [NSString stringWithFormat:@"[ RETRY TIMES ] %@", @(count)],
                 [NSString stringWithFormat:@"[ TIMEOUT INTERVAL ] %@", @(self.sessionManager.requestSerializer.timeoutInterval)],
                 [NSString stringWithFormat:@"[ HEADERS ] %@", self.sessionManager.requestSerializer.HTTPRequestHeaders]);
            
            count--;
            
            NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:messages[0]]];
            NSURLSessionDownloadTask *downloadTask = [self.sessionManager downloadTaskWithRequest:request progress:nil destination:^NSURL * _Nonnull(NSURL * _Nonnull targetPath, NSURLResponse * _Nonnull response) {
                // 保存路径
                return [NSURL fileURLWithPath:messages[1]];
            } completionHandler:^(NSURLResponse * _Nonnull response, NSURL * _Nullable filePath, NSError * _Nullable error) {
                if (!error) {
                    [self parseWithMethod:FLNetworkRequestMethodDownload response:(NSHTTPURLResponse *)response result:filePath messages:messages callback:callback];
                } else {
                    if (count < 1) [self parseWithMethod:FLNetworkRequestMethodDownload response:(NSHTTPURLResponse *)response result:error messages:messages callback:callback];
                    else [self sendWithMethod:FLNetworkRequestMethodDownload retryTimes:count messages:messages response:callback];
                }
            }];
            [downloadTask resume];
        }
            break;
        default:
            break;
    }
}

// 数据处理
- (void)parseWithMethod:(FLNetworkRequestMethod)method response:(NSHTTPURLResponse *)response result:(id)result messages:(NSArray *)messages callback:(WXModuleCallback)callback
{
    // 回调结果到 Web 端
    if (response.statusCode == 200) {
        switch (method) {
            case FLNetworkRequestMethodGET:
            case FLNetworkRequestMethodPOST:
            case FLNetworkRequestMethodDELETE:
            {
                if ([result isKindOfClass:[NSDictionary class]]) {
                    DLog(@"[ REQUEST ] Success", [NSString stringWithFormat:@"[ URL ] %@", messages[0]]);
                    callback(@{@"statusCode": @(response.statusCode), @"resultData": result});
                } else {
                    DLog(@"[ REQUEST ] Success but not JSON data", [NSString stringWithFormat:@"[ URL ] %@", messages[0]]);
                    callback(@{@"statusCode": @(response.statusCode), @"resultData": result});
                }
            }
                break;
            case FLNetworkRequestMethodDownload:
            {
                if ([result isKindOfClass:[NSURL class]]) {
                    DLog(@"[ REQUEST ] Success", [NSString stringWithFormat:@"[ URL ] %@", messages[0]]);
                    callback(@{@"statusCode": @(response.statusCode), @"resultData": result});
                } else {
                    DLog(@"[ REQUEST ] Success but error file", [NSString stringWithFormat:@"[ URL ] %@", messages[0]]);
                    callback(@{@"statusCode": @(response.statusCode), @"resultData": result});
                }
            }
                break;
            default:
                break;
        }
    } else {
        DLog(@"[ REQUEST ] Failure", [NSString stringWithFormat:@"[ URL ] %@", messages[0]]);
        callback(@{@"statusCode": @(response.statusCode), @"resultData": result});
    }
}


#pragma mark - Weex Module Methods (Web -> Native)

// Web 调用 -> 设置超时时隔
- (void)timeout_interval:(NSNumber *)messages
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    self.timeoutInterval = [messages integerValue] / 1000;
}

// Web 调用 -> 设置重试次数
- (void)retry_times:(NSNumber *)messages
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    self.retryTimes = [messages integerValue];
}

// Web 调用 -> 设置请求头
- (void)set_headers:(NSDictionary *)messages
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    [messages enumerateKeysAndObjectsUsingBlock:^(id _Nonnull key, id _Nonnull obj, BOOL * _Nonnull stop) {
        [self.sessionManager.requestSerializer setValue:obj forHTTPHeaderField:key];
    }];
}

// Web 调用 -> 发送 GET 请求
- (void)request_get:(NSArray *)messages callback:(WXModuleCallback)callback
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    [self sendWithMethod:FLNetworkRequestMethodGET retryTimes:self.retryTimes messages:messages response:callback];
}

// Web 调用 -> 发送 POST 请求
- (void)request_post:(NSArray *)messages callback:(WXModuleCallback)callback
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    [self sendWithMethod:FLNetworkRequestMethodPOST retryTimes:self.retryTimes messages:messages response:callback];
}

// Web 调用 -> 发送 DELETE 请求
- (void)request_delete:(NSArray *)messages callback:(WXModuleCallback)callback
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    [self sendWithMethod:FLNetworkRequestMethodDELETE retryTimes:self.retryTimes messages:messages response:callback];
}

// Web 调用 -> 发送下载请求
- (void)request_download:(NSArray *)messages callback:(WXModuleCallback)callback
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    [self sendWithMethod:FLNetworkRequestMethodDownload retryTimes:self.retryTimes messages:messages response:callback];
}

// Web 调用 -> 重置请求
- (void)reset_request
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    self.timeoutInterval = 120;
    self.retryTimes = 1;
}

// Web 调用 -> 打开网络监听
- (void)start_monitoring:(WXModuleKeepAliveCallback)callback
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    [self.reachabilityManager startMonitoring];
    callback(NULL, YES);
    [self.reachabilityManager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        switch (status) {
            case AFNetworkReachabilityStatusUnknown:
                callback(FL_NETWORK_REACHABILITY_STATUS_UNKNOWN, YES);
                break;
            case AFNetworkReachabilityStatusNotReachable:
                callback(FL_NETWORK_REACHABILITY_STATUS_NONE, YES);
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN:
                callback(FL_NETWORK_REACHABILITY_STATUS_WWAN, YES);
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi:
                callback(FL_NETWORK_REACHABILITY_STATUS_WIFI, YES);
                break;
            default:
                break;
        }
    }];
}

// Web 调用 -> 关闭网络监听
- (void)stop_monitoring
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    [self.reachabilityManager stopMonitoring];
}

// Web 调用 -> 网络状态
- (void)network_reachability:(WXModuleCallback)callback
{
    DLog([NSString stringWithFormat:@"[ FUNCTION ] '%@' run", NSStringFromSelector(_cmd)]);
    if (self.reachabilityManager.networkReachabilityStatus == AFNetworkReachabilityStatusReachableViaWWAN) {
        callback(FL_NETWORK_REACHABILITY_STATUS_WWAN);
    } else if (self.reachabilityManager.networkReachabilityStatus == AFNetworkReachabilityStatusReachableViaWiFi) {
        callback(FL_NETWORK_REACHABILITY_STATUS_WIFI);
    } else {
        callback(FL_NETWORK_REACHABILITY_STATUS_NONE);
    }
}

@end
