//
//  WeexSDKManager.h
//  WeexDemo
//
//  Created by yangshengtao on 16/11/14.
//  Copyright © 2016年 taobao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeexSDKManager : NSObject

+ (void)setup;


@end
