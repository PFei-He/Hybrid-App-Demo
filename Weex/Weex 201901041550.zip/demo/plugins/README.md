# use weexpack add plugin 

#### add a plugin 

``` bash
weexpack plugin add plugin_name
```

